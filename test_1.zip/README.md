# Prado PHP Framework - Basic appliction project

PRADO is a component-based and event-driven programming framework for developing Web applications in PHP 5.
PRADO stands for PHP Rapid Application Development Object-oriented.

This repo contains a basic application project for Prado4.
In order to use this project, you neeed to install composer:

    $ curl -s http://getcomposer.org/installer | php

Then, use it to create the application structure:
	
	$ composer create-project pradosoft/prado-app app

The `app` directory will contain the application.