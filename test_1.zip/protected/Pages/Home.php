<?php

class Home extends BasicPage
{
	public function onLoad($param)
	{
		parent::onLoad($param);

		if(!$this->getIsPostBack())
		{
		}
	}
	public function convert_clicked($sender, $param)
    {
		if($this->Page->IsValid)
    	{
			//die('ll');
			$rate = floatval($this->currencyRate->Text);
			$dollars = floatval($this->dollars->Text);
			$this->total->Text = $rate * $dollars;
		}
    }
}
